﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Xml.Linq;

namespace detMatrix
{
    internal class Matrix
    {
        private double[,] matrix;
        private int matrixSize;
        public List<string> CalculationSteps { get; private set; } = new List<string>();

        public Matrix(double[,] matrix, int matrixSize)
        {
            this.matrix = matrix;
            this.matrixSize = matrixSize;
            
        }

        public int MatrixSize
        {
            get
            {
                return matrixSize;
            }
            set
            {
                if (value < 2 || value > 11)
                {
                    throw new ArgumentException("Размерность матрицы должна быть от 2 до 10");
                }
                else
                {
                    this.matrixSize = value;
                }
            }
        }

        public double this[int i, int j]
        {
            get
            {
                return matrix[i, j];
            }
            set
            {
                matrix[i, j] = value;
            }
        }

        //проверка на нижнюю треугольную матрицу
        public bool isDownTriangle()
        {
            for (int i = 0; i < matrixSize; i++)
            {
                for (int j = 0; j < i; j++)
                {
                    if (matrix[i, j] != 0)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        // проверка на верхнюю треугольную матрицу
        public bool isUpTriangle()
        {
            for (int i = 0; i < matrixSize; i++)
            {
                for (int j = i + 1; j < matrixSize; j++)
                {
                    if (matrix[i, j] != 0)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public bool isNullMatrix()
        {
            for (int i = 0; i < matrixSize; i++)
            {
                for (int j = 0; j < matrixSize; j++)
                {
                    if (matrix[i, j] != 0)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        //перед этим методом должна быть проверка на треугольную матрицу
        public double isDeterminantMainDiagonal()
        {
            string result = $"Определитель = ";
            double determinant = 1;
            for (int i = 0; i < matrixSize; i++)
            {
                determinant *= matrix[i, i];
                result += $" {matrix[i, i]} ";
                if (i < matrixSize - 1)
                {
                    result += $"*";
                }
                else
                {
                    result += $"= {determinant}";
                }
            }
            CalculationSteps.Add(result);
            return determinant;
        }

        public double determinant()
        {
            double determinant = 0;

            if (this.isNullMatrix())
            {
                CalculationSteps.Add($"Определитель нулевой матрицы равен нулю");
                return determinant;
            }
            else if (this.isUpTriangle() || this.isDownTriangle())
            {
                CalculationSteps.Add($"Определитель треугольной матрицы равен произведению элементов её главной диагонали: a11*а22*...*ann");
                determinant = this.isDeterminantMainDiagonal();
                return determinant;
            }
            if (matrixSize == 2)
            {
                double det = matrix[0, 0] * matrix[1, 1] - matrix[0, 1] * matrix[1, 0];
                CalculationSteps.Add($"Определитель = a11 * a22 - a12 * a21 = {matrix[0, 0]} * {matrix[1, 1]} - {matrix[0, 1]} * {matrix[1, 0]} = {det}");
                return det;
            }

            if (matrixSize == 3)
            {
                double det = matrix[0, 0] * (matrix[1, 1] * matrix[2, 2] - matrix[1, 2] * matrix[2, 1]) +
                              matrix[0, 1] * (matrix[1, 2] * matrix[2, 0] - matrix[1, 0] * matrix[2, 2]) +
                              matrix[0, 2] * (matrix[1, 0] * matrix[2, 1] - matrix[1, 1] * matrix[2, 0]);
                string calcSteps = $"Определитель = a11*(a22*a33 - a23*a32) + a12*(a23*a31 - a21*a33) + a13*(a21*a32 - a22*a31)";
                calcSteps += $"= {matrix[0, 0]} * ({matrix[1, 1]} * {matrix[2, 2]} - {matrix[1, 2]} * {matrix[2, 1]}) + " +
                                     $"{matrix[0, 1]} * ({matrix[1, 2]} * {matrix[2, 0]} - {matrix[1, 0]} * {matrix[2, 2]}) + " +
                                     $"{matrix[0, 2]} * ({matrix[1, 0]} * {matrix[2, 1]} - {matrix[1, 1]} * {matrix[2, 0]}) = {det}";
                CalculationSteps.Add(calcSteps);
                return det;
            }

            List<Matrix> calculatedMinors = new List<Matrix>();
            string calcStepsForBigDimensions = "";
            for (int j = 0; j < matrixSize; j++)
            {
                var minorMatrixVal = minorMatrix(0, j); 
                determinant += (j % 2 == 0 ? 1 : -1) * matrix[0, j] * minorMatrixVal.determinant();
                calculatedMinors.Add(minorMatrixVal);
                if (j > 0)
                {
                    calcStepsForBigDimensions += " ";
                }
                calcStepsForBigDimensions += $"{((j % 2 == 0) ? "+" : "-")} {matrix[0, j]} * минор(0,{j})";
            }
            CalculationSteps.Add($"Данный определитель вычисляется через алгебраические дополнения по элементам первой строки: 𝐴𝑖𝑗 = (−1)^(𝑖+𝑗) * a𝑖𝑗 * 𝑀𝑖𝑗.");
            CalculationSteps.Add($"Далее эти элементы складываются");
            CalculationSteps.Add($"Минором 𝑀𝑖𝑗, соответствующим элементу 𝑎𝑖𝑗 определителя 𝑛 – го порядка, называется определитель (𝑛 − 1) – го порядка,получающийся из исходного вычеркиванием 𝑖–й строки и 𝑗– го столбца.");
            CalculationSteps.Add($"Для вычисления данного определителя складываем");
            CalculationSteps.Add($"Определитель = {calcStepsForBigDimensions} = {determinant}");
            CalculationSteps.Add($"Вычисления миноров: ");

            for (int j = 0; j < matrixSize; j++)
            {
                var matrix = calculatedMinors[j];
                CalculationSteps.Add(Environment.NewLine);
                CalculationSteps.Add($"Расчет определителя для минора(0, {j}): ");
                CalculationSteps.Add(this.MatrixToString(matrix.matrix));
                CalculationSteps.AddRange(matrix.CalculationSteps);
            }

            return determinant;
        }


        private Matrix minorMatrix(int row, int col)
        {
            double[,] newMatrix = new double[matrixSize - 1, matrixSize - 1];
            int newRow = 0, newCol;

            for (int i = 0; i < matrixSize; i++)
            {
                if (i == row)
                {
                    continue; // Пропускаем строку
                }

                newCol = 0;
                for (int j = 0; j < matrixSize; j++)
                {
                    if (j == col)
                    {
                        continue; // Пропускаем столбец
                    }

                    newMatrix[newRow, newCol] = matrix[i, j];
                    newCol++;
                }
                newRow++;
            }

            Matrix subMatrix = new Matrix(newMatrix, matrixSize - 1);
            return subMatrix;
        }

        public string MatrixToString(double[,] matrix)
        {
            StringBuilder sb = new StringBuilder();
            int size = matrix.GetLength(0);
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    sb.Append(matrix[i, j]);
                    if (j < (size - 1))
                    {
                        sb.Append("\t"); // Добавляем пробел между элементами
                    }
                }
                sb.AppendLine(); // Новая строка после каждой строки матрицы
            }
            return sb.ToString();
        }
    }
}
