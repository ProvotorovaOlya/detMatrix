﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace detMatrix
{
    /// <summary>
    /// 
    /// 
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private readonly int dimension;
        private double[,] matrix;
        private TextBox[,] textBoxes; // Для хранения ссылок на TextBox
        public Window1(int _dimension)
        {

            InitializeComponent();
            dimension = _dimension;
            MatrixDimensionText.Text = $"Размерность матрицы: {dimension}x{dimension}";
            textBoxes = new TextBox[dimension, dimension]; // Инициализация массива TextBox
            CreateMatrixInputFields(); // Создание полей ввода
            textBoxes[0, 0].Focus(); // Устанавливаем фокус на первый элемент

        }

        private void CreateMatrixInputFields()
        {

            // Добавить строки и столбцы в Grid
            for (int i = 0; i < dimension; i++)
            {
                MainGrid.RowDefinitions.Add(new RowDefinition()); // Добавляем строку
                for (int j = 0; j < dimension; j++)
                {
                    if (i == 0) // Добавляем столбцы только один раз
                    {
                        MainGrid.ColumnDefinitions.Add(new ColumnDefinition()); // Добавляем столбец
                    }

                    TextBox textBox = new TextBox
                    {
                        Width = 50,
                        Height = 30,
                        Margin = new Thickness(5),
                        FontSize = 16,
                        Foreground = new SolidColorBrush(Color.FromRgb(40, 40, 40)), // черный цвет текста
                        Background = new SolidColorBrush(Color.FromRgb(249, 249, 249)), // белый фон для текстбоксов
                        BorderBrush = new SolidColorBrush(Color.FromRgb(40, 40, 40)), // Цвет рамки - фиолетовый
                        BorderThickness = new Thickness(1),
                        VerticalAlignment = VerticalAlignment.Center,
                        HorizontalAlignment = HorizontalAlignment.Center // Центрируем текстбокс

                    };

                    textBox.KeyDown += TextBox_KeyDown; // метод KeyDown для клавиатуры

                    // Установить позицию TextBox в сетке
                    Grid.SetRow(textBox, i + 3);
                    Grid.SetColumn(textBox, j + 1);

                    // Добавить TextBox в Grid
                    MainGrid.Children.Add(textBox);
                    textBoxes[i, j] = textBox; // Сохраняем ссылку на TextBox
                }
            }
        }

        //не работает перемещение по клавиатуре
        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                CalculateDeterminant_Click(sender, e); // Вызываем метод вычисления определителя
            }
            else if (e.Key == Key.Right)
            {
                MoveFocus(sender, 0, 1); // Перемещение вправо
                e.Handled = true; // Указываем, что событие обработано
            }
            else if (e.Key == Key.Left)
            {
                MoveFocus(sender, 0, -1); // Перемещение влево
                e.Handled = true; // Указываем, что событие обработано
            }
            else if (e.Key == Key.Up)
            {
                MoveFocus(sender, -1, 0); // Перемещение вверх
                e.Handled = true; // Указываем, что событие обработано
            }
            else if (e.Key == Key.Down)
            {
                MoveFocus(sender, 1, 0); // Перемещение вниз
                e.Handled = true; // Указываем, что событие обработано
            }
        }

        private void MoveFocus(object sender, int rowOffset, int colOffset)
        {
            // Находим текущий TextBox
            TextBox currentTextBox = sender as TextBox;
            if (currentTextBox != null)
            {
                // Получаем индексы текущего TextBox
                int currentRow = Grid.GetRow(currentTextBox) - 3; // Вычитаем смещение
                int currentCol = Grid.GetColumn(currentTextBox) - 1;

                // Вычисляем новые индексы
                int newRow = currentRow + rowOffset;
                int newCol = currentCol + colOffset;

                // Проверяем границы массива
                if (newRow >= 0 && newRow < dimension && newCol >= 0 && newCol < dimension)
                {
                    // Устанавливаем фокус на новый TextBox
                    textBoxes[newRow, newCol].Focus();
                }
            }
        }

        private void CalculateDeterminant_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Получаем введенные элементы матрицы
                matrix = new double[dimension, dimension];
                List<TextBox> errorTextBoxes = new List<TextBox>(); // Список для хранения TextBox с ошибками

                foreach (var child in MainGrid.Children)
                {
                    if (child is TextBox tb)
                    {
                        var rowIndex = Grid.GetRow(tb) - 3; // Вычитаем смещение
                        var colIndex = Grid.GetColumn(tb) - 1;

                        if (!double.TryParse(tb.Text.Trim(), out matrix[rowIndex, colIndex]))
                        {
                            errorTextBoxes.Add(tb); // Добавляем TextBox с ошибкой в список
                        }
                    }
                }

                // Если есть ошибки, выводим сообщение и очищаем поля с ошибками
                if (errorTextBoxes.Count > 0)
                {
                    StringBuilder errorMessage = new StringBuilder("Неверный ввод: \n 1) Проверьте заполнены ли все ячейки для ввода элементов матрицы.\n 2) Все значения элементов матрицы есть действительные числа.\n Некорректные значения в следующих ячейках:\n");
                    foreach (var tb in errorTextBoxes)
                    {
                        errorMessage.AppendLine($"Ячейка ({Grid.GetRow(tb) - 3 + 1}, {Grid.GetColumn(tb)})"); // +1 для отображения в 1-индексном формате
                        tb.Clear(); // Очищаем текстовое поле с ошибкой
                    }
                    MessageBox.Show(errorMessage.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return; // Прерываем выполнение метода
                }

                // Открываем второе окно и передаем туда размерность и саму матрицу
                Window2 window2 = new Window2(dimension, matrix);
                window2.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
