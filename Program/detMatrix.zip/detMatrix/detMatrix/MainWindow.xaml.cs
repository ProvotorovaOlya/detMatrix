﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace detMatrix
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded; // Подписываемся на событие загрузки окна
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            DimensionInput.Focus(); // Устанавливаем фокус на поле ввода
        }

        private void DimensionInput_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void DimensionInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) // Проверяем, была ли нажата клавиша Enter
            {
                CreateMatrix_Click(sender, e); // Вызываем метод создания матрицы
            }
        }

        private void CreateMatrix_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(DimensionInput.Text, out int dimension) && dimension > 1 && dimension < 11)
            {
                Window1 taskWindow = new Window1(dimension);
                taskWindow.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите корректную размерность матрицы (от 2 до 10).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                DimensionInput.Clear(); // Очищаем поле ввода
            }

        }
    }
}