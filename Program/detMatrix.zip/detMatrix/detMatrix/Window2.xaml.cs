﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace detMatrix
{

    public partial class Window2 : Window
    {
        private readonly int dimension;
        private readonly double[,] matrix;

        public Window2(int _dimension, double[,] _matrix)
        {
            InitializeComponent();
            dimension = _dimension;
            matrix = _matrix;

            Matrix myMatrix = new Matrix(matrix, dimension);
            double determinant = myMatrix.determinant();
            StepsTextBox.Text = "Исходная матрица:";
            StepsTextBox.Text += Environment.NewLine + myMatrix.MatrixToString(matrix);
            StepsTextBox.Text += String.Join(Environment.NewLine, myMatrix.CalculationSteps);

            Answer.Text = $"Определитель = {determinant}";
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Window1 taskWindow = new Window1(dimension);
            taskWindow.Show();
            //this.Close();
        }
    }

}
